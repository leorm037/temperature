// Version: 2020-08-22
//
    // o--------------------------------------------------------------------------------o
    // | This file is part of the RGraph package - you can learn more at:               |
    // |                                                                                |
    // |                         https://www.rgraph.net                                 |
    // |                                                                                |
    // | RGraph is licensed under the Open Source MIT license. That means that it's     |
    // | totally free to use and there are no restrictions on what you can do with it!  |
    // o--------------------------------------------------------------------------------o

    RGraph = window.RGraph || {isrgraph:true,isRGraph:true,rgraph:true};

    //
    // The traditional radar chart constructor
    // 
    // @param string id   The ID of the canvas
    // @param array  data An array of data to represent
    //
    RGraph.Radar = function (conf)
    {
        // Turn conf.data into a multi-d array if it's not already
        if (typeof conf.data[0] === 'number' || typeof conf.data[0] === 'string') {
            conf.data = [conf.data];
        }

        this.id                = conf.id;
        this.canvas            = document.getElementById(conf.id);
        this.context           = this.canvas.getContext ? this.canvas.getContext("2d") : null;
        this.canvas.__object__ = this;
        this.type              = 'radar';
        this.isRGraph          = true;
        this.isrgraph          = true;
        this.rgraph            = true;
        this.data              = [];
        this.max               = 0;
        this.uid               = RGraph.createUID();
        this.canvas.uid        = this.canvas.uid ? this.canvas.uid : RGraph.createUID();
        this.colorsParsed      = false;
        this.coords            = [];
        this.coordsText        = [];
        this.original_data     = [];
        this.original_colors   = [];
        this.firstDraw         = true; // After the first draw this will be false





        //
        // Add the data to the .original_data array and work out the max value
        // 
        // 2/5/14 Now also use this loop to ensure that the data pieces
        //        are numbers
        //
        for (var i=0,len=conf.data.length; i<len; ++i) {
        
            // Convert strings to numbers
            for (var j=0; j<conf.data[i].length; ++j) {
                if (typeof conf.data[i][j] === 'string') {
                    conf.data[i][j] = parseFloat(conf.data[i][j]);
                }
            }
        
            this.original_data.push(RGraph.arrayClone(conf.data[i]));
            this.data.push(RGraph.arrayClone(conf.data[i]));
            this.max = Math.max(this.max, RGraph.arrayMax(conf.data[i]));
        }


        this.properties =
        {
            marginLeft:           35,
            marginRight:          35,
            marginTop:            35,
            marginBottom:         35,

            linewidth:             1,

            colorsStroke:           '#aaa',
            colors:                ['rgba(255,0,0,0.75)','rgba(0,255,255,0.25)','rgba(255,0,0,0.5)', 'red', 'green', 'blue', 'pink', 'aqua','brown','orange','grey'],
            colorsAlpha:          null,
            circle:                0,

            circleFill:           'red',
            circleStroke:         'black',

            labels:                [],
            labelsFont:           null,
            labelsSize:           null,
            labelsColor:          null,
            labelsBold:           null,
            labelsSize:           null,
            labelsOffset:         10,
            labelsAxes:            '',
            labelsBackgroundFill: 'white',
            labelsBoxed:           false,
            labelsAxesFont:       null,
            labelsAxesSize:       null,
            labelsAxesColor:      null,
            labelsAxesBold:       null,
            labelsAxesItalic:     null,
            labelsAxesBoxed:      null, // This defaults to true - but that's set in the Draw() method
            labelsAxesBoxedZero: true,
            labelsAxesBoxedBackground: 'rgba(255,255,255,0.7)',
            labelsAxesSpecific:   null,
            labelsAxesCount:      5,

            backgroundCircles:    true,
            backgroundCirclesCount: null,
            backgroundCirclesColor: '#ddd',
            backgroundCirclesPoly:  true,
            backgroundCirclesSpokes: 24,

            textSize:             12,
            textFont:             'Arial, Verdana, sans-serif',
            textColor:            'black',
            textBold:             false,
            textItalic:           false,
            textAccessible:               true,
            textAccessibleOverflow:      'visible',
            textAccessiblePointerevents: false,

            title:                 '',
            titleBackground:      null,
            titleHpos:            null,
            titleVpos:            null,
            titleColor:           null,
            titleBold:            null,
            titleItalic:          null,
            titleSize:            null,
            titleFont:            null,
            titleX:               null,
            titleY:               null,
            titleHalign:          null,
            titleValign:          null,

            linewidth:             1,

            key:                   null,
            keyBackground:        'white',
            keyShadow:            false,
            keyShadowColor:       '#666',
            keyShadowBlur:        3,
            keyShadowOffsetx:     2,
            keyShadowOffsety:     2,
            keyPosition:          'graph',
            keyHalign:             'right',
            keyPositionGutterBoxed: false,
            keyPositionX:         null,
            keyPositionY:         null,
            keyColorShape:        'square',
            keyRounded:            true,
            keyLinewidth:          1,
            keyColors:             null,
            keyInteractive:        false,
            keyInteractiveHighlightChartStroke: 'rgba(255,0,0,0.3)',
            keyInteractiveHighlightLabel: 'rgba(255,0,0,0.2)',
            keyLabelsColor:        null,
            keyLabelsFont:         null,
            keyLabelsSize:         null,
            keyLabelsBold:         null,
            keyLabelsItalic:       null,
            keyLabelsOffsetx:      0,
            keyLabelsOffsety:      0,

            contextmenu:           null,

            annotatable:           false,
            annotateColor:        'black',
            annotateLinewidth:    1,

            tooltips:                   null,
            tooltipsEvent:              'mousemove',
            tooltipsEffect:             'fade',
            tooltipsCssClass:           'RGraph_tooltip',
            tooltipsCss:                null,
            tooltipsHighlight:          true,
            tooltipsNohideonclear:      false,
            tooltipsFormattedThousand:  ',',
            tooltipsFormattedPoint:     '.',
            tooltipsFormattedDecimals:  0,
            tooltipsFormattedUnitsPre:  '',
            tooltipsFormattedUnitsPost: '',
            tooltipsFormattedKeyColors: null,
            tooltipsFormattedKeyColorsShape: 'square',
            tooltipsFormattedKeyLabels: [],
            tooltipsFormattedTableHeaders: null,
            tooltipsFormattedTableData: null,
            tooltipsPointer:            true,
            tooltipsPositionStatic:     true,

            highlightStroke:       'gray',
            highlightFill:         'rgba(255,255,255,0.7)',
            highlightPointRadius: 2,

            resizable:              false,
            resizeHandleAdjust:   [0,0],
            resizeHandleBackground: null,

            scaleMax:              null,
            scaleDecimals:         0,
            scalePoint:            '.',
            scaleThousand:         ',',
            scaleUnitsPre:        '',
            scaleUnitsPost:       '',

            accumulative:           false,

            radius:                 null,

            centerx:              null,
            centery:              null,
            radius:               null,

            xaxisTickmarksCount:  5,

            yaxisTickmarksCount:  5,

            axesColor:           'rgba(0,0,0,0)',

            highlights:           false,
            highlightsStroke:    '#ddd',
            highlightsFill:      null,
            highlightsRadius:    3,
            highlightStyleInvertStroke: 'transparent',
            highlightStyleInvertFill: 'rgba(255,255,255,0.7)',

            fillClick:           null,
            fillMousemove:       null,
            fillTooltips:        null,
            fillHighlightFill:   'rgba(255,255,255,0.7)',
            fillHighlightStroke: 'rgba(0,0,0,0)',
            fillMousemoveRedraw: false,

            animationTraceClip: 1,

            clearto:   'rgba(0,0,0,0)'
        }



        // Must have at least 3 points
        for (var dataset=0; dataset<this.data.length; ++dataset) {
            if (this.data[dataset].length < 3) {
                alert('[RADAR] You must specify at least 3 data points');
                return;
            }
        }
        
        
        //
        // Linearize the data and then create the $ objects
        //
        var idx = 0;
        this.data_arr = [];
        for (var dataset=0; dataset<this.data.length; ++dataset) {
            for (var i=0,len=this.data[dataset].length; i<len; ++i) {
                this['$' + (idx++)] = {};
                this.data_arr.push(this.data[dataset][i])
            }
        }



        //
        // Translate half a pixel for antialiasing purposes - but only if it hasn't beeen
        // done already
        //
        if (!this.canvas.__rgraph_aa_translated__) {
            this.context.translate(0.5,0.5);
            
            this.canvas.__rgraph_aa_translated__ = true;
        }




        // Easy access to  properties and the path function
        var prop  = this.properties;
        this.path = RGraph.pathObjectFunction;
        
        
        
        //
        // "Decorate" the object with the generic effects if the effects library has been included
        //
        if (RGraph.Effects && typeof RGraph.Effects.decorate === 'function') {
            RGraph.Effects.decorate(this);
        }
        
        
        
        // Add the responsive method. This method resides in the common file.
        this.responsive = RGraph.responsive;








        //
        // A simple setter
        //
        this.set = function (name)
        {
            var value = typeof arguments[1] === 'undefined' ? null : arguments[1];

            // the number of arguments is only one and it's an
            // object - parse it for configuration data and return.
            if (arguments.length === 1 && typeof arguments[0] === 'object') {
                for (i in arguments[0]) {
                    if (typeof i === 'string') {
                        this.set(i, arguments[0][i]);
                    }
                }

                return this;
            }

            prop[name] = value;

            return this;
        };








        //
        // A simple getter
        // 
        // @param string name  The name of the property to get
        //
        this.get = function (name)
        {
            return prop[name];
        };






 

        //
        // The draw method which does all the brunt of the work
        //
        this.draw = function ()
        {
            //
            // Fire the onbeforedraw event
            //
            RGraph.fireCustomEvent(this, 'onbeforedraw');
            
            // NB: Colors are parsed further down
    
            // Reset the coords array to stop it growing
            this.coords     = [];
            this.coords2    = [];
            this.coordsText = [];
    
            //
            // Reset the data to the original_data
            //
            this.data = RGraph.arrayClone(this.original_data);

            // Loop thru the data array if the accumulative option is enable checking to see if all the
            // datasets have the same number of elements.
            if (prop.accumulative) {
                for (var i=0; i<this.data.length; ++i) {
                    if (this.data[i].length != this.data[0].length) {
                        alert('[RADAR] Error! When the radar has the accumulative option set to true all the datasets must have the same number of elements');
                    }
                }
            }
    
    
            //
            // This defaults to true, but needs to be an array with a size matching the number of
            // labels.
            //
            if (RGraph.isNull(prop.labelsAxesBoxed)) {
                prop.labelsAxesBoxed = [];
                for (var i=0; i<( (RGraph.isArray(prop.labelsAxesSpecific) && prop.labelsAxesSpecific.length) || prop.labelsAxesCount || 5); ++i) {
                    prop.labelsAxesBoxed[i] = false;
                }
            }



            //
            // Make the margins easy to access
            //            
            this.marginLeft   = prop.marginLeft;
            this.marginRight  = prop.marginRight;
            this.marginTop    = prop.marginTop;
            this.marginBottom = prop.marginBottom;
    
            this.centerx  = ((this.canvas.width - this.marginLeft - this.marginRight) / 2) + this.marginLeft;
            this.centery  = ((this.canvas.height - this.marginTop - this.marginBottom) / 2) + this.marginTop;
            this.radius   = Math.min(this.canvas.width - this.marginLeft - this.marginRight, this.canvas.height - this.marginTop - this.marginBottom) / 2;
    
    
    
            //
            // Allow these to be set by hand
            //
            if (typeof prop.centerx === 'number') this.centerx = 2 * prop.centerx;
            if (typeof prop.centery === 'number') this.centery = 2 * prop.centery;
            if (typeof prop.radius  === 'number') this.radius  = prop.radius;
    
    
            //
            // Parse the colors for gradients. Its down here so that the center X/Y can be used
            //
            if (!this.colorsParsed) {
    
                this.parseColors();
    
                // Don't want to do this again
                this.colorsParsed = true;
            }
    
    
    
            // Work out the maximum value and the sum
            if (!prop.scaleMax) {
    
                // this.max is calculated in the constructor
    
                // Work out this.max again if the chart is (now) set to be accumulative
                if (prop.accumulative) {
                    
                    var accumulation = [];
                    var len = this.original_data[0].length
    
                    for (var i=1; i<this.original_data.length; ++i) {
                        if (this.original_data[i].length != len) {
                            alert('[RADAR] Error! Stacked Radar chart datasets must all be the same size!');
                        }
                        
                        for (var j=0; j<this.original_data[i].length; ++j) {
                            this.data[i][j] += this.data[i - 1][j];
                            this.max = Math.max(this.max, this.data[i][j]);
                        }
                    }
                }
    
    
                this.scale2 = RGraph.getScale({object: this, options: {
                    'scale.max':          typeof prop.scaleMax === 'number' ? prop.scaleMax : this.max,
                    'scale.min':          0,
                    'scale.decimals':     Number(prop.scaleDecimals),
                    'scale.point':        prop.scalePoint,
                    'scale.thousand':     prop.scaleThousand,
                    'scale.round':        prop.scaleRound,
                    'scale.units.pre':    prop.scaleUnitsPre,
                    'scale.units.post':   prop.scaleUnitsPost,
                    'scale.labels.count': prop.labelsAxesCount
                }});
                this.max = this.scale2.max;
    
            } else {
                
                var ymax = prop.scaleMax;
    
                this.scale2 = RGraph.getScale({object: this, options: {
                    'scale.max':          ymax,
                    'scale.min':          0,
                    'scale.strict':       true,
                    'scale.decimals':     Number(prop.scaleDecimals),
                    'scale.point':        prop.scalePoint,
                    'scale.thousand':     prop.scaleThousand,
                    'scale.round':        prop.scaleRound,
                    'scale.units.pre':    prop.scaleUnitsPre,
                    'scale.units.post':   prop.scaleUnitsPost,
                    'scale.labels.count': prop.labelsAxesCount
                }});
                this.max = this.scale2.max;
            }

            this.drawBackground();
            this.drawAxes();
            this.drawCircle();
            this.drawLabels();


            //
            // Allow clipping (for the trace() effect for example)
            //
            this.context.save();
                this.context.beginPath();
                    this.context.arc(this.centerx, this.centery, this.radius * 2, -RGraph.HALFPI, (RGraph.TWOPI * prop.animationTraceClip) - RGraph.HALFPI, false);
                    this.context.lineTo(this.centerx, this.centery);
                this.context.closePath();
                this.context.clip();
    
                this.drawChart();
                this.drawHighlights();
            this.context.restore();
            
            //
            // Draw the axis labels
            //
            this.drawAxisLabels();
            
            // Draw the title
            if (prop.title) {
                RGraph.drawTitle(
                    this,
                    prop.title,
                    this.marginTop,
                    null,
                    null
                )
            }
    
            // Draw the key if necessary
            // obj, key, colors
            if (prop.key) {
                RGraph.drawKey(this, prop.key, prop.colors);
            }
    
            //
            // Show the context menu
            //
            if (prop.contextmenu) {
                RGraph.showContext(this);
            }
    
            
            //
            // This function enables resizing
            //
            if (prop.resizable) {
                RGraph.allowResizing(this);
            }
    
    
            //
            // This installs the event listeners
            //
            RGraph.installEventListeners(this);

            //
            // This installs the Radar chart specific area listener
            //
            if ( (prop.fillClick || prop.fillMousemove || !RGraph.isNull(prop.fillTooltips)) && !this.__fill_click_listeners_installed__) {
                this.addFillListeners();
                this.__fill_click_listeners_installed__ = true;
            }



            //
            // Fire the onfirstdraw event
            //
            if (this.firstDraw) {
                this.firstDraw = false;
                RGraph.fireCustomEvent(this, 'onfirstdraw');
                this.firstDrawFunc();
            }




            //
            // Fire the RGraph draw event
            //
            RGraph.fireCustomEvent(this, 'ondraw');
            
            return this;
        };








        //
        // Used in chaining. Runs a function there and then - not waiting for
        // the events to fire (eg the onbeforedraw event)
        // 
        // @param function func The function to execute
        //
        this.exec = function (func)
        {
            func(this);
            
            return this;
        };








        //
        // Draws the background circles
        //
        this.drawBackground = function ()
        {
            var color   = prop.backgroundCirclesColor;
            var poly    = prop.backgroundCirclesPoly;
            var spacing = prop.backgroundCirclesSpacing;
            var spokes  = prop.backgroundCirclesSpokes;
    
    
    
    
            // Set the linewidth for the grid (so that repeated redrawing works OK)
            this.context.lineWidth = 1;
    
    
    
    
            //
            // Draws the background circles
            //
            if (prop.backgroundCircles && poly == false) {
    
    
    
    
    
                // Draw the concentric circles
                this.context.strokeStyle = color;
               this.context.beginPath();
                    
                    var numrings = typeof prop.backgroundCirclesCount == 'number' ? prop.backgroundCirclesCount : prop.labelsAxesCount;

                    // TODO Currently set to 5 - needs changing
                   for (var r=0; r<=this.radius; r+=(this.radius / numrings)) {
                        this.context.moveTo(this.centerx, this.centery);
                        this.context.arc(this.centerx, this.centery,r, 0, RGraph.TWOPI, false);
                    }
                this.context.stroke();
    
    
    
    
        
                //
                // Draw the diagonals/spokes
                //
                this.context.strokeStyle = color;
    
                for (var i=0; i<360; i+=(360 / spokes)) {
                    this.context.beginPath();
                        this.context.arc(
                            this.centerx,
                            this.centery,
                            this.radius,
                            (i / 360) * RGraph.TWOPI,
                            ((i+0.001) / 360) * RGraph.TWOPI,
                            false
                        ); // The 0.01 avoids a bug in Chrome 6
                        this.context.lineTo(this.centerx, this.centery);
                    this.context.stroke();
                }
    
    
    
    
    
    
            //
            // The background"circles" are actually drawn as a poly based on how
            // many points there are
            // (ie hexagons if there are 6 points, squares if there are four etc)
            //
            } else if (prop.backgroundCircles && poly == true) {

                //
                // Draw the diagonals/spokes
                //
                this.context.strokeStyle = color;
                var increment = 360 / this.data[0].length
    
                for (var i=0; i<360; i+=increment) {

                    this.context.beginPath();
                        this.context.arc(
                            this.centerx,
                            this.centery,
                            this.radius,
                            ((i / 360) * RGraph.TWOPI) - RGraph.HALFPI,
                            (((i + 0.001) / 360) * RGraph.TWOPI) - RGraph.HALFPI,
                        false); // The 0.001 avoids a bug in Chrome 6
                        this.context.lineTo(this.centerx, this.centery);
                    this.context.stroke();
                }
    
    
                //
                // Draw the lines that go around the Radar chart
                //
                this.context.strokeStyle = color;
                
                var numrings = typeof prop.backgroundCirclesCount === 'number' ? prop.backgroundCirclesCount : prop.labelsAxesCount;

                for (var r=0; r<=this.radius; r+=(this.radius / numrings)) {
                    this.context.beginPath();
                        for (var a=0; a<=360; a+=(360 / this.data[0].length)) {
                            this.context.arc(
                                this.centerx,
                                this.centery,
                                r,
                                RGraph.toRadians(a) - RGraph.HALFPI,
                                RGraph.toRadians(a) + 0.001 - RGraph.HALFPI,
                                false
                            );
                        }
                    this.context.closePath();
                    this.context.stroke();
                }
            }
        };








        //
        // Draws the axes
        //
        this.drawAxes = function ()
        {
            this.context.strokeStyle = prop.axesColor;
            this.context.lineWidth   = prop.axesLinewidth;
    
            var halfsize = this.radius;
    
            this.context.beginPath();
                //
                // The Y axis
                //
                this.context.moveTo(Math.round(this.centerx), this.centery + this.radius);
                this.context.lineTo(Math.round(this.centerx), this.centery - this.radius);
                
        
                // Draw the bits at either end of the Y axis
                this.context.moveTo(this.centerx - 5, Math.round(this.centery + this.radius));
                this.context.lineTo(this.centerx + 5, Math.round(this.centery + this.radius));
                this.context.moveTo(this.centerx - 5, Math.round(this.centery - this.radius));
                this.context.lineTo(this.centerx + 5, Math.round(this.centery - this.radius));
    
                // Draw Y axis tick marks
                for (var y=(this.centery - this.radius); y<(this.centery + this.radius); y+=(this.radius/prop.yaxisTickmarksCount)) {
                    this.context.moveTo(this.centerx - 3, Math.round(y));
                    this.context.lineTo(this.centerx + 3, Math.round(y));
                }
        
                //
                // The X axis
                //
                this.context.moveTo(this.centerx - this.radius, Math.round(this.centery));
                this.context.lineTo(this.centerx + this.radius, Math.round(this.centery));
        
                // Draw the bits at the end of the X axis
                this.context.moveTo(Math.round(this.centerx - this.radius), this.centery - 5);
                this.context.lineTo(Math.round(this.centerx - this.radius), this.centery + 5);
                this.context.moveTo(Math.round(this.centerx + this.radius), this.centery - 5);
                this.context.lineTo(Math.round(this.centerx + this.radius), this.centery + 5);
        
                // Draw X axis tick marks
                for (var x=(this.centerx - this.radius); x<(this.centerx + this.radius); x+=(this.radius/prop.xaxisTickmarksCount)) {
                    this.context.moveTo(Math.round(x), this.centery - 3);
                    this.context.lineTo(Math.round(x), this.centery + 3);
                }
    
            // Stroke it
            this.context.stroke();
        };








        //
        // The function which actually draws the radar chart
        //
        this.drawChart = function ()
        {
            var alpha = prop.colorsAlpha;
    
            if (typeof alpha == 'number') {
                var oldAlpha = this.context.globalAlpha;
                this.context.globalAlpha = alpha;
            }

            var numDatasets = this.data.length;
    
            for (var dataset=0; dataset<this.data.length; ++dataset) {
    
                this.context.beginPath();
    
                    var coords_dataset = [];
        
                    for (var i=0; i<this.data[dataset].length; ++i) {
                        
                        var coords = this.getCoordinates(dataset, i);
    
                        if (coords_dataset == null) {
                            coords_dataset = [];
                        }
    
                        coords_dataset.push(coords);
                        this.coords.push(coords);
                    }
                    
                    this.coords2[dataset] = coords_dataset;
                    
    
                    //
                    // Now go through the coords and draw the chart itself
                    //
                    // 18/5/2012 - colorsStroke can now be an array of colors as well as a single color
                    //
    
                    this.context.strokeStyle = (typeof prop.colorsStroke == 'object' && prop.colorsStroke[dataset]) ? prop.colorsStroke[dataset] : prop.colorsStroke;
                    this.context.fillStyle   = prop.colors[dataset] ? prop.colors[dataset] : 'rgba(0,0,0,0)';
                    if (this.context.fillStyle === 'transparent') {
                        this.context.fillStyle = 'rgba(0,0,0,0)';
                    }
                    this.context.lineWidth   = prop.linewidth;
    
                    for (i=0; i<coords_dataset.length; ++i) {
                        if (i == 0) {
                            this.context.moveTo(coords_dataset[i][0], coords_dataset[i][1]);
                        } else {
                            this.context.lineTo(coords_dataset[i][0], coords_dataset[i][1]);
                        }
                    }
                    
    
                    // If on the second or greater dataset, backtrack
                    if (prop.accumulative && dataset > 0) {
    
                        // This goes back to the start coords of this particular dataset
                        this.context.lineTo(coords_dataset[0][0], coords_dataset[0][1]);
                        
                        //Now move down to the end point of the previous dataset
                        this.context.moveTo(last_coords[0][0], last_coords[0][1]);
    
                        for (var i=coords_dataset.length - 1; i>=0; --i) {
                            this.context.lineTo(last_coords[i][0], last_coords[i][1]);
                        }
                    }
                
                // This is used by the next iteration of the loop
                var last_coords = coords_dataset;
    
                this.context.closePath();
        
                this.context.fill();
                this.context.stroke();
            }
            
            // Reset the globalAlpha
            if (typeof alpha == 'number') {
                this.context.globalAlpha = oldAlpha;
            }
        };








        //
        // Gets the coordinates for a particular mark
        // 
        // @param  number i The index of the data (ie which one it is)
        // @return array    A two element array of the coordinates
        //
        this.getCoordinates = function (dataset, index)
        {
            // The number  of data points
            var len = this.data[dataset].length;
    
            // The magnitude of the data (NOT the x/y coords)
            var mag = (this.data[dataset][index] / this.max) * this.radius;
    
            //
            // Get the angle
            //
            var angle = (RGraph.TWOPI / len) * index; // In radians
                angle -= RGraph.HALFPI;
    
    
            //
            // Work out the X/Y coordinates
            //
            var x = Math.cos(angle) * mag;
            var y = Math.sin(angle) * mag;
    
            //
            // Put the coordinate in the right quadrant
            //
            x = this.centerx + x;
            y = this.centery + y;
            
            return [x,y];
        };








        //
        // This function adds the labels to the chart
        //
        this.drawLabels = function ()
        {
            var labels = prop.labels;

            if (labels && labels.length > 0) {
    
                this.context.lineWidth = 1;
                this.context.strokeStyle = 'gray';
                this.context.fillStyle = prop.labelsColor || prop.textColor;
                
                var bgFill  = prop.labelsBackgroundFill,
                    bold    = prop.labelsBold,
                    bgBoxed = prop.labelsBoxed,
                    offset  = prop.labelsOffset,
                    font    = prop.textFont,
                    size    = prop.textSize,
                    radius  = this.radius,
                    color   = prop.labelsColor || prop.textColor

                for (var i=0; i<labels.length; ++i) {
                    
                    var angle  = (RGraph.TWOPI / prop.labels.length) * i;
                        angle -= RGraph.HALFPI;
    
                    var x = this.centerx + (Math.cos(angle) * (radius + offset));
                    var y = this.centery + (Math.sin(angle) * (radius + offset));

                    //
                    // Horizontal alignment
                    //
                    var halign = x < this.centerx ? 'right' : 'left' ;
                    if (i == 0 || (i / labels.length) == 0.5) halign = 'center';
    
                    if (labels[i] && labels[i].length) {
                        
                        var textConf = RGraph.getTextConf({
                            object: this,
                            prefix: 'labels'
                        });
                       
                        RGraph.text({
                            
                       object: this,
                    
                         font: textConf.font,
                         size: textConf.size,
                        color: textConf.color,
                         bold: textConf.bold,
                       italic: textConf.italic,

                            x:              x,
                            y:              y,
                            text:           labels[i],
                            valign:         'center',
                            halign:         halign,
                            bounding:       bgBoxed,
                            boundingFill:   bgFill,
                            tag:            'labels'
                        });
                    }
                }
            }
        };








        //
        // Draws the circle. No arguments as it gets the information from the object properties.
        //
        this.drawCircle = function ()
        {
            var circle = {};
                circle.limit  = prop.circle;
                circle.fill   = prop.circleFill;
                circle.stroke = prop.circleStroke;
    
            if (circle.limit) {
    
                var r = (circle.limit / this.max) * this.radius;
                
                this.context.fillStyle = circle.fill;
                this.context.strokeStyle = circle.stroke;
    
                this.context.beginPath();
                this.context.arc(this.centerx, this.centery, r, 0, RGraph.TWOPI, 0);
                this.context.fill();
                this.context.stroke();
            }
        };








        //
        // Draws the labels
        //
        this.drawAxisLabels = function ()
        {
            //
            // Draw specific axis labels
            //
            if (RGraph.isArray(prop.labelsAxesSpecific) && prop.labelsAxesSpecific.length) {
                this.drawSpecificAxisLabels();
                return;
            }
    
            this.context.lineWidth = 1;
            
            // Set the color to black
            this.context.fillStyle   = 'black';
            this.context.strokeStyle = 'black';
    
            var r          = this.radius,
                font       = prop.textFont,
                axes       = prop.labelsAxes.toLowerCase(),
                color      = prop.labelsAxesBoxedBackground,
                drawzero   = false,
                units_pre  = prop.scaleUnitsPre,
                units_post = prop.scaleUnitsPost,
                decimals   = prop.scaleDecimals,
                bold       = prop.labelsAxesBold,
                boxed      = prop.labelsAxesBoxed,
                centerx    = this.centerx,
                centery    = this.centery,
                scale      = this.scale;

            this.context.fillStyle = prop.textColor;
            
            var textConf = RGraph.getTextConf({
                object: this,
                prefix: 'labelsAxes'
            });

            // The "North" axis labels
            if (axes.indexOf('n') > -1) {
            
                for (var i=0; i<this.scale2.labels.length; ++i) {
                    RGraph.text({
                        
                   object: this,

                     font: textConf.font,
                     size: textConf.size,
                    color: textConf.color,
                     bold: textConf.bold,
                   italic: textConf.italic,

                        x:              centerx,
                        y:              centery - (r * ((i+1)/this.scale2.labels.length)),
                        text:           this.scale2.labels[i],
                        valign:         'center',
                        halign:         'center',
                        bounding:       boxed[i] || color,
                        boundingFill:   color,
                        boundingStroke: 'rgba(0,0,0,0)',
                        tag:            'scale'
                    });
                }
                
                drawzero = true;
            }
    
            // The "South" axis labels
            if (axes.indexOf('s') > -1) {
                for (var i=0; i<this.scale2.labels.length; ++i) {
                    RGraph.text({
                        
                   object: this,

                     font: textConf.font,
                     size: textConf.size,
                    color: textConf.color,
                     bold: textConf.bold,
                   italic: textConf.italic,

                        x:              centerx,
                        y:              centery + (r * ((i+1)/this.scale2.labels.length)),
                        text:           this.scale2.labels[i],
                        valign:         'center',
                        halign:         'center',
                        bounding:       boxed[i] || color,
                        boundingFill:   color,
                        boundingStroke: 'rgba(0,0,0,0)',
                        tag:            'scale'
                    });
                }
                
                drawzero = true;
            }
            
            // The "East" axis labels
            if (axes.indexOf('e') > -1) {
                
                for (var i=0; i<this.scale2.labels.length; ++i) {
                    RGraph.text({
                        
                   object: this,

                     font: textConf.font,
                     size: textConf.size,
                    color: textConf.color,
                     bold: textConf.bold,
                   italic: textConf.italic,

                        x:              centerx + (r * ((i+1)/this.scale2.labels.length)),
                        y:              centery,
                        text:           this.scale2.labels[i],
                        valign:         'center',
                        halign:         'center',
                        bounding:       boxed[i]|| color,
                        boundingFill:   color,
                        boundingStroke: 'rgba(0,0,0,0)',
                        tag:            'scale'
                    });
                }
    
                drawzero = true;
            }
    
            // The "West" axis labels
            if (axes.indexOf('w') > -1) {
    
                for (var i=0; i<this.scale2.labels.length; ++i) {
                    RGraph.text({
                        
                   object: this,

                     font: textConf.font,
                     size: textConf.size,
                    color: textConf.color,
                     bold: textConf.bold,
                   italic: textConf.italic,

                        x:              centerx - (r * ((i+1)/this.scale2.labels.length)),
                        y:              centery,
                        text:           this.scale2.labels[i],
                        valign:         'center',
                        halign:         'center',
                        bounding:       boxed[i]|| color,
                        boundingFill:   color,
                        boundingStroke: 'rgba(0,0,0,0)',
                        tag:            'scale'
                    });
                }
    
                drawzero = true;
            }
    
            if (drawzero) {
                RGraph.text({
                    
               object: this,

                 font: textConf.font,
                 size: textConf.size,
                color: textConf.color,
                 bold: textConf.bold,
               italic: textConf.italic,

                    x:              centerx,
                    y:              centery,
                    text: RGraph.numberFormat({
                        object:    this,
                        number:    Number(0).toFixed(),
                        unitspre:  units_pre,
                        unitspost: units_post
                    }),
                    valign:         'center',
                    halign:         'center',
                    bounding:       color ? true : false,
                    boundingFill:   color,
                    boundingStroke: 'rgba(0,0,0,0)',
                    tag:            'scale'
                });
            }
        };








        //
        // Draws specific axis labels
        //
        this.drawSpecificAxisLabels = function ()
        {
            //
            // Specific axis labels
            //
            var labels          = prop.labelsAxesSpecific;
            var bold            = RGraph.arrayPad(prop.labelsAxesBold,labels.length);
            var boxed           = RGraph.arrayPad(prop.labelsAxesBoxed,labels.length);
            var reversed_labels = RGraph.arrayReverse(labels);
            var reversed_bold   = RGraph.arrayReverse(bold);
            var reversed_boxed  = RGraph.arrayReverse(boxed);
            var font            = prop.textFont;
            var axes            = prop.labelsAxestextowerCase();
            
            this.context.fillStyle = prop.textColor;
            
            var textConf = RGraph.getTextConf({
                object: this,
                prefix: 'labelsAxes'
            });
            
             
            for (var i=0; i<labels.length; ++i) {
    
                if (axes.indexOf('n') > -1) RGraph.text({object: this,font: textConf.font,size: textConf.size,color: textConf.color,bold: textConf.bold,italic: textConf.italic,tag: 'labels.axes.specific', x:this.centerx,y:this.centery - this.radius + ((this.radius / labels.length) * i),text:reversed_labels[i],valign:'center',halign:'center',bounding:reversed_boxed[i],boundingFill:'white'});
                if (axes.indexOf('s') > -1) RGraph.text({object: this,font: textConf.font,size: textConf.size,color: textConf.color,bold: textConf.bold,italic: textConf.italic,tag: 'labels.axes.specific', x:this.centerx,y:this.centery + ((this.radius / labels.length) * (i+1)),text:labels[i],valign:'center',halign:'center',bounding:boxed[i],boundingFill:'white'});
                
                if (axes.indexOf('w') > -1) RGraph.text({object: this,font: textConf.font,size: textConf.size,color: textConf.color,bold: textConf.bold,italic: textConf.italic,tag: 'labels.axes.specific', x:this.centerx - this.radius + ((this.radius / labels.length) * i),y:this.centery,text:reversed_labels[i],valign:'center',halign:'center',bounding:reversed_boxed[i],boundingFill:'white'});
                if (axes.indexOf('e') > -1) RGraph.text({object: this,font: textConf.font,size: textConf.size,color: textConf.color,bold: textConf.bold,italic: textConf.italic,tag: 'labels.axes.specific', x:this.centerx + ((this.radius / labels.length) * (i+1)),y:this.centery,text:labels[i],valign:'center',halign:'center',bounding:boxed[i],boundingFill:'white'});
            }
        };








        //
        // This method eases getting the focussed point (if any)
        // 
        // @param event e The event object
        //
        this.getShape = function (e)
        {
            for (var i=0; i<this.coords.length; ++i) {

                var x        = this.coords[i][0];
                var y        = this.coords[i][1];
                var tooltips = prop.tooltips;
                var index    = Number(i);
                var mouseXY  = RGraph.getMouseXY(e);
                var mouseX   = mouseXY[0];
                var mouseY   = mouseXY[1];
    
                if (   mouseX < (x + 5)
                    && mouseX > (x - 5)
                    && mouseY > (y - 5)
                    && mouseY < (y + 5)
                   ) {

                    if (RGraph.parseTooltipText) {
                        var tooltip = RGraph.parseTooltipText(prop.tooltips, index);
                    }

                    var indexes = RGraph.sequentialIndexToGrouped(index, this.data);
                    var dataset = indexes[0];
                    var idx     = indexes[1];

                    return {
                     object: this,
                          x: x,
                          y: y,
                      index: idx,
                    dataset: dataset,
            sequentialIndex: index,
                      label: prop.labels && typeof prop.labels[idx] === 'string' ? prop.labels[idx] : null,
                    tooltip: typeof tooltip === 'string' ? tooltip : null
                    }
                }
            }
        };








        //
        // Each object type has its own Highlight() function which highlights the appropriate shape
        // 
        // @param object shape The shape to highlight
        //
        this.highlight = function (shape)
        {
            if (typeof prop.highlightStyle === 'function') {
                (prop.highlightStyle)(shape);
            
            
            
            
            
            // Inverted highlighting
            } else if (prop.highlightStyle === 'invert') {
            
                var radius = 25;

                this.path(
                    'b a % % % % % true',
                    shape.x,shape.y,radius,4.72, -1.57
                );

               for (var a=0; a<=360; a+=(360 / this.data[0].length)) {
                    this.path('a % % % % % false');
                    this.context.arc(
                        this.centerx,
                        this.centery,
                        this.radius,
                        RGraph.toRadians(a) - RGraph.HALFPI,
                        RGraph.toRadians(a) + 0.001 - RGraph.HALFPI,
                        false
                    );
                }
                
                // Go back to the top of the chart and then stroke/fill it
                this.path(
                    'a % % % % % false c f %',
                    this.centerx,this.centery,this.radius,0 - RGraph.HALFPI,0.001 - RGraph.HALFPI,
                    prop.highlightFill
                );
                
                // Draw the stroke around the circular cutout
                this.path(
                    'b a % % % % % false s %',
                    shape.x,shape.y,radius,0,6.29,
                    prop.highlightStroke
                );







            } else {
                RGraph.Highlight.point(this, shape);
            }
        };








        //
        // The getObjectByXY() worker method. Don't call this call:
        // 
        // RGraph.ObjectRegistry.getObjectByXY(e)
        // 
        // @param object e The event object
        //
        this.getObjectByXY = function (e)
        {
            var mouseXY = RGraph.getMouseXY(e);
            var extra   = 5;
    
            if (
                   mouseXY[0] > (this.centerx - this.radius - extra)
                && mouseXY[0] < (this.centerx + this.radius + extra)
                && mouseXY[1] > (this.centery - this.radius - extra)
                && mouseXY[1] < (this.centery + this.radius + extra)
                ) {
    
                return this;
            }
        };








        //
        // This draws highlights on the points
        //
        this.drawHighlights = function ()
        {
            if (prop.highlights) {
                
                var sequentialIdx = 0;
                var dataset       = 0;
                var index         = 0;
                var radius        = prop.highlightsRadius;
                
    
                
                for (var dataset=0; dataset <this.data.length; ++dataset) {
                    for (var index=0; index<this.data[dataset].length; ++index) {
                        this.context.beginPath();
                            this.context.strokeStyle = prop.highlightsStroke;
                            this.context.fillStyle = prop.highlightsFill ? prop.highlightsFill : ((typeof prop.colorsStroke == 'object' && prop.colorsStroke[dataset]) ? prop.colorsStroke[dataset] : prop.colorsStroke);
                            this.context.arc(this.coords[sequentialIdx][0], this.coords[sequentialIdx][1], radius, 0, RGraph.TWOPI, false);
                        this.context.stroke();
                        this.context.fill();
                        ++sequentialIdx;
                    }
                }
                
            }
        };








        //
        // This function returns the radius (ie the distance from the center) for a particular
        // value. Note that if you want the angle for a point you can use getAngle(index)
        // 
        // @param number value The value you want the radius for
        //
        this.getRadius = function (value)
        {
            if (value < 0 || value > this.max) {
                return null;
            }
    
            // Radar doesn't support minimum value
            var radius = (value / this.max) * this.radius;
            
            return radius;
        };








        //
        // This function returns the angle (in radians) for a particular index.
        // 
        // @param number numitems The total number of items
        // @param number index    The zero index number of the item to get the angle for
        //
        this.getAngle = function (numitems, index)
        {
            var angle = (RGraph.TWOPI / numitems) * index;
                angle -= RGraph.HALFPI;
            
            return angle;
        };








        //
        // This allows for easy specification of gradients
        //
        this.parseColors = function ()
        {
            // Save the original colors so that they can be restored when the canvas is reset
            if (this.original_colors.length === 0) {
                this.original_colors.colors          = RGraph.arrayClone(prop.colors);
                this.original_colors.keyColors       = RGraph.arrayClone(prop.keyColors);
                this.original_colors.titleColor      = RGraph.arrayClone(prop.titleColor);
                this.original_colors.textColor       = RGraph.arrayClone(prop.textColor);
                this.original_colors.labelsColor     = RGraph.arrayClone(prop.labelsColor);
                this.original_colors.labelsAxesColor = RGraph.arrayClone(prop.labelsAxesColor);
                this.original_colors.highlightStroke = RGraph.arrayClone(prop.highlightStroke);
                this.original_colors.highlightFill   = RGraph.arrayClone(prop.highlightFill);
                this.original_colors.circleFill      = RGraph.arrayClone(prop.circleFill);
                this.original_colors.circleStroke    = RGraph.arrayClone(prop.circleStroke);
                this.original_colors.colorsStroke    = RGraph.arrayClone(prop.colorsStroke);
            }

            for (var i=0; i<prop.colors.length; ++i) {
                prop.colors[i] = this.parseSingleColorForGradient(prop.colors[i]);
            }
            
            var keyColors = prop.keyColors;
    
            if (typeof keyColors != 'null' && keyColors && keyColors.length) {
                for (var i=0; i<prop.keyColors.length; ++i) {
                    prop.keyColors[i] = this.parseSingleColorForGradient(prop.keyColors[i]);
                }
            }
    
            prop.titleColor      = this.parseSingleColorForGradient(prop.titleColor);
            prop.textColor       = this.parseSingleColorForGradient(prop.textColor);
            prop.labelsColor     = this.parseSingleColorForGradient(prop.labelsColor);
            prop.labelsAxesColor= this.parseSingleColorForGradient(prop.labelsAxesColor);
            prop.highlightStroke = this.parseSingleColorForGradient(prop.highlightStroke);
            prop.highlightFill   = this.parseSingleColorForGradient(prop.highlightFill);
            prop.circleFill      = this.parseSingleColorForGradient(prop.circleFill);
            prop.circleStroke    = this.parseSingleColorForGradient(prop.circleStroke);
            
            // Strokestyle can be an array
            if (typeof prop.colorsStroke === 'object') {
                for (var i=0; i<prop.colorsStroke.length; ++i) {
                    prop.colorsStroke[i] = this.parseSingleColorForGradient(prop.colorsStroke[i]);
                }
            } else {
                prop.colorsStroke = this.parseSingleColorForGradient(prop.colorsStroke);
            }
        };








        //
        // Use this function to reset the object to the post-constructor state. Eg reset colors if
        // need be etc
        //
        this.reset = function ()
        {
        };








        //
        // This parses a single color value
        //
        this.parseSingleColorForGradient = function (color)
        {
            if (!color || typeof color != 'string') {
                return color;
            }

            if (color.match(/^gradient\((.*)\)$/i)) {

                // Allow for JSON gradients
                if (color.match(/^gradient\(({.*})\)$/i)) {
                    return RGraph.parseJSONGradient({object: this, def: RegExp.$1});
                }

                var parts = RegExp.$1.split(':');
    
                // Create the gradient
                var grad = this.context.createRadialGradient(this.centerx, this.centery, 0, this.centerx, this.centery, this.radius);
    
                var diff = 1 / (parts.length - 1);
    
                grad.addColorStop(0, RGraph.trim(parts[0]));
    
                for (var j=1; j<parts.length; ++j) {
                    grad.addColorStop(j * diff, RGraph.trim(parts[j]));
                }
            }
    
            return grad ? grad : color;
        };








        this.addFillListeners = function (e)
        {
            var obj = this;

            var func = function (e)
            {
                //var canvas  = e.target;
                //var context = canvas.getContext('2d');
                var coords  = obj.coords;
                var coords2 = obj.coords2;
                var mouseXY = RGraph.getMouseXY(e);
                var dataset = 0;

                if (e.type == 'mousemove' && prop.fillMousemoveRedraw) {
                    RGraph.redrawCanvas(obj.canvas);
                }

                for (var dataset=(obj.coords2.length-1); dataset>=0; --dataset) {
                    
                    // Draw the path again so that it can be checked
                    obj.context.beginPath();
                        obj.context.moveTo(obj.coords2[dataset][0][0], obj.coords2[dataset][0][1]);
                        for (var j=0; j<obj.coords2[dataset].length; ++j) {
                            obj.context.lineTo(obj.coords2[dataset][j][0], obj.coords2[dataset][j][1]);
                        }
                        
                    // Draw a line back to the starting point
                    obj.context.lineTo(obj.coords2[dataset][0][0], obj.coords2[dataset][0][1]);
        
                    // Go thru the previous datasets coords in reverse order
                    if (prop.accumulative && dataset > 0) {
                        obj.context.lineTo(obj.coords2[dataset - 1][0][0], obj.coords2[dataset - 1][0][1]);
                        for (var j=(obj.coords2[dataset - 1].length - 1); j>=0; --j) {
                            obj.context.lineTo(obj.coords2[dataset - 1][j][0], obj.coords2[dataset - 1][j][1]);
                        }
                    }
    
                    obj.context.closePath();
                    
                    if (obj.context.isPointInPath(mouseXY[0], mouseXY[1])) {
                        var inPath = true;
                        break;
                    }
                }
                
                // Call the events
                if (inPath) {
    
                    var fillTooltips = prop.fillTooltips;
    
                    //
                    // Click event
                    //
                    if (e.type == 'click') {
                        if (prop.fillClick) {
                            prop.fillClick(e, dataset);
                        }
                    
                        if (prop.fillTooltips && prop.fillTooltips[dataset]) {
                            obj.datasetTooltip(e, dataset);
                        }
                    }

    
    
                    //
                    // Mousemove event
                    //
                    if (e.type == 'mousemove') {
    
                        if (prop.fillMousemove) {
                            prop.fillMousemove(e, dataset);
                        }
                        
                        if (!RGraph.isNull(fillTooltips)) {
                            e.target.style.cursor = 'pointer';
                        }
                    
                        if (prop.fillTooltips && prop.fillTooltips[dataset]) {
                            e.target.style.cursor = 'pointer';
                        }
                    }
    
                    e.stopPropagation();
                
                } else if (e.type == 'mousemove') {
                    obj.canvas.style.cursor = 'default';
                }
            };
            
            //
            // Add the click listener
            //
            if (prop.fillClick || !RGraph.isNull(prop.fillTooltips)) {
                this.canvas.addEventListener('click', func, false);
            }
    
            //
            // Add the mousemove listener
            //
            if (prop.fillMousemove || !RGraph.isNull(prop.fillTooltips)) {
                this.canvas.addEventListener('mousemove', func, false);
            }
        };








        //
        // This highlights a specific dataset on the chart
        // 
        // @param number dataset The index of the dataset (which starts at zero)
        //
        this.highlightDataset = function (dataset)
        {
            this.context.beginPath();
            for (var j=0; j<this.coords2[dataset].length; ++j) {
                if (j == 0) {
                    this.context.moveTo(this.coords2[dataset][0][0], this.coords2[dataset][0][1]);
                } else {
                    this.context.lineTo(this.coords2[dataset][j][0], this.coords2[dataset][j][1]);
                }
            }
    
            this.context.lineTo(this.coords2[dataset][0][0], this.coords2[dataset][0][1]);
            
            if (prop.accumulative && dataset > 0) {
                this.context.lineTo(this.coords2[dataset - 1][0][0], this.coords2[dataset - 1][0][1]);
                for (var j=(this.coords2[dataset - 1].length - 1); j>=0; --j) {
                    this.context.lineTo(this.coords2[dataset - 1][j][0], this.coords2[dataset - 1][j][1]);
                }
            }
    
            this.context.strokeStyle = prop.fillHighlightStroke;
            this.context.fillStyle   = prop.fillHighlightFill;
    
            this.context.stroke();
            this.context.fill();
        };








        //
        // Shows a tooltip for a dataset (a "fill" tooltip), You can pecify these
        // with the fillTooltips option
        //
        this.datasetTooltip = function (e, dataset)
        {
            // Highlight the dataset
            this.highlightDataset(dataset);

            // Use the First datapoints coords for the Y position of the tooltip NOTE The X position is changed in the
            // obj.positionTooltip() method so set the index to be the first one
            var text = prop.fillTooltips[dataset];
            var x    = this.coords2[dataset][0][0] + RGraph.getCanvasXY(this.canvas)[0];
            var y    = this.coords2[dataset][0][1] + RGraph.getCanvasXY(this.canvas)[1];
    

            // Show a tooltip
            RGraph.tooltip({
                object: this,
                  text: text,
                     x: x,
                     y: y,
                 index: 0,
                 event: e
                });
        };








        //
        // This function handles highlighting an entire data-series for the interactive
        // key
        // 
        // @param int index The index of the data series to be highlighted
        //
        this.interactiveKeyHighlight = function (index)
        {
            var coords = this.coords2[index];

            if (coords) {
                
                var pre_linewidth = this.context.lineWidth;
                var pre_linecap   = this.context.lineCap;
                
                
                
                
                // ------------------------------------------ //

                this.context.lineWidth   = prop.linewidth + 10;
                this.context.lineCap     = 'round';
                this.context.strokeStyle = prop.keyInteractiveHighlightChartStroke;

                
                this.context.beginPath();
                for (var i=0,len=coords.length; i<len; i+=1) {
                    if (i == 0) {
                        this.context.moveTo(coords[i][0], coords[i][1]);
                    } else {
                        this.context.lineTo(coords[i][0], coords[i][1]);
                    }
                }
                this.context.closePath();
                this.context.stroke();
                
                // ------------------------------------------ //
                
                
                
                
                // Reset the lineCap and lineWidth
                this.context.lineWidth = pre_linewidth;
                this.context.lineCap = pre_linecap;
            }
        };








        //
        // Using a function to add events makes it easier to facilitate method chaining
        // 
        // @param string   type The type of even to add
        // @param function func 
        //
        this.on = function (type, func)
        {
            if (type.substr(0,2) !== 'on') {
                type = 'on' + type;
            }
            
            if (typeof this[type] !== 'function') {
                this[type] = func;
            } else {
                RGraph.addCustomEventListener(this, type, func);
            }
    
            return this;
        };








        //
        // This function runs once only
        // (put at the end of the file (before any effects))
        //
        this.firstDrawFunc = function ()
        {
        };








        //
        // Radar chart grow
        // 
        // This effect gradually increases the magnitude of the points on the radar chart
        // 
        // @param object     Options for the effect
        // @param function   An optional callback that is run when the effect is finished
        //
        this.grow = function ()
        {
            var obj           = this;
            var callback      = arguments[1] ? arguments[1] : function () {};
            var opt           = arguments[0] ? arguments[0] : {};
            var frames        = opt.frames ? opt.frames : 30;
            var frame         = 0;
            var data          = RGraph.arrayClone(obj.data);

            function iterator ()
            {
                for (var i=0,len=data.length; i<len; ++i) {

                    //if (obj.original_data[i] == null) {
                    //    obj.original_data[i] = [];
                    //}
    
                    for (var j=0,len2=data[i].length; j<len2; ++j) {
                        obj.original_data[i][j] = (frame / frames)  * data[i][j];
                    }
                }
    
                RGraph.clear(obj.canvas);
                RGraph.redrawCanvas(obj.canvas);
    
                if (frame < frames) {
                    frame++;
                    RGraph.Effects.updateCanvas(iterator);
                } else {
                    callback(obj);
                }
            }
            
            iterator();
            
            return this;
        };








        //
        // Trace (Radar chart)
        // 
        // This is a Trace effect for the Radar chart
        // 
        // @param object     Options for the effect. Currently only "frames" is available.
        // @param function   A function that is called when the ffect is complete
        //
        this.trace = function ()
        {
            var obj       = this;
            var opt       = arguments[0] || {};
            var frames    = opt.frames || 60;
            var frame     = 0;
            var callback  = arguments[1] || function () {};
    
            obj.set('animationTraceClip', 0);


            var iterator = function ()
            {
                if (frame < frames) {
        
                    obj.set('animationTraceClip', frame / frames);
        
                    frame++;
                    RGraph.redrawCanvas(obj.canvas);
                    RGraph.Effects.updateCanvas(iterator);

                } else {

                    obj.set('animationTraceClip', 1);
                    RGraph.redrawCanvas(obj.canvas);
                    callback(obj);
                }
            };
            
            iterator();
            
            return this;
        };








        //
        // A worker function that handles Bar chart specific tooltip substitutions
        //
        this.tooltipSubstitutions = function (opt)
        {
            var indexes = RGraph.sequentialIndexToGrouped(opt.index, this.data);

            // Create the values array which contains each datasets value
            for (var i=0,values=[]; i<this.data.length; ++i) {
                values.push(this.data[i][indexes[1]]);
            }

            return {
                  index: indexes[1],
                dataset: indexes[0],
        sequentialIndex: opt.index,
                  value: this.data_arr[opt.index],
                 values: values
            };
        };








        //
        // A worker function that returns the correct color/label/value
        //
        // @param object specific The indexes that are applicable
        // @param number index    The appropriate index
        //
        this.tooltipsFormattedCustom = function (specific, index)
        {
            var color = (   !RGraph.isNull((prop.tooltipsFormattedKeyColors))
                        && typeof prop.tooltipsFormattedKeyColors === 'object'
                        && prop.tooltipsFormattedKeyColors[i])
                           ? prop.tooltipsFormattedKeyColors[i]
                           : '';

            var label = (   !RGraph.isNull((prop.tooltipsFormattedKeyLabels))
                        && typeof prop.tooltipsFormattedKeyLabels === 'object'
                        && prop.tooltipsFormattedKeyLabels[index])
                           ? prop.tooltipsFormattedKeyLabels[index]
                           : '';
            return {
                label: label,
                color: color
            };
        };








        //
        // This allows for static tooltip positioning
        //
        this.positionTooltipStatic = function (args)
        {
            var obj      = args.object,
                e        = args.event,
                tooltip  = args.tooltip,
                index    = args.index,
                canvasXY = RGraph.getCanvasXY(obj.canvas)
                coords   = this.coords[index];

            // Position the tooltip in the X direction
            args.tooltip.style.left = (
                canvasXY[0]                      // The X coordinate of the canvas
                + coords[0]                      // The X coordinate of the point on the chart
                - (tooltip.offsetWidth / 2)      // Subtract half of the tooltip width
                + obj.properties.tooltipsOffsetx // Add any user defined offset
            ) + 'px';

            args.tooltip.style.top  = (
                  canvasXY[1]                    // The Y coordinate of the canvas
                + coords[1]                      // The Y coordinate of the bar on the chart
                - tooltip.offsetHeight           // The height of the tooltip
                + obj.properties.tooltipsOffsety // Add any user defined offset
                - 15
                - (prop.highlightsRadius - 4)
            ) + 'px';
        };








        //
        // Always register the object
        //
        RGraph.register(this);








        //
        // This is the 'end' of the constructor so if the first argument
        // contains configuration data - handle that.
        //
        RGraph.parseObjectStyleConfig(this, conf.options);
    };